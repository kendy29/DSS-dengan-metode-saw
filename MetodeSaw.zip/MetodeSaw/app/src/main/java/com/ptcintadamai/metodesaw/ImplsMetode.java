package com.ptcintadamai.metodesaw;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class ImplsMetode extends AppCompatActivity {
    DatabaseHelper db;
    ListView listView;
    ListView listView2;
    listAdapter adapter=null;
    listAdapter2 adapter2=null;
    ArrayList<item> list;
    ArrayList<item2> list2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_impls_metode);

    }
}
