package com.ptcintadamai.metodesaw;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class listAdapter extends BaseAdapter {


    private Context c;
    private int layout;
    private ArrayList<item> foodlist;
    public listAdapter(Context c, int layout, ArrayList<item> foodlist) {
        this.c = c;
        this.layout = layout;
        this.foodlist = foodlist;
    }
    @Override
    public int getCount() {
        return foodlist.size();
    }

    @Override
    public Object getItem(int position) {
        return foodlist.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View v, ViewGroup parent) {
        viewHolder holder = new viewHolder();
            View view = v;
        if (view==null){
            LayoutInflater inflater=(LayoutInflater)c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view=inflater.inflate(layout,null);


            holder.txt1=(TextView)view.findViewById(R.id.txt1);
            holder.txt2=(TextView)view.findViewById(R.id.txt2);
            holder.txt3=(TextView)view.findViewById(R.id.txt3);
            holder.txt4=(TextView)view.findViewById(R.id.txt4);
            holder.txt5=(TextView)view.findViewById(R.id.txt5);
            view.setTag(holder);

        }else{
            holder=(viewHolder)view.getTag();
        }
        item f = foodlist.get(position);
        holder.txt1.setText(f.getPu());
        holder.txt2.setText(f.getTk());
        holder.txt3.setText(f.getTp());
        holder.txt4.setText(f.getPd());
        holder.txt5.setText(f.getUp());



        return view;
    }
    private class viewHolder{

        TextView txt1, txt2, txt3, txt4, txt5;
    }
}
