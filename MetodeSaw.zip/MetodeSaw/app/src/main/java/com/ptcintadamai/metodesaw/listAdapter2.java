package com.ptcintadamai.metodesaw;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class listAdapter2 extends BaseAdapter {


    private Context c;
    private int layout;
    private ArrayList<item2> foodlist;
    public listAdapter2(Context c, int layout, ArrayList<item2> foodlist) {
        this.c = c;
        this.layout = layout;
        this.foodlist = foodlist;
    }
    @Override
    public int getCount() {
        return foodlist.size();
    }

    @Override
    public Object getItem(int position) {
        return foodlist.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View v, ViewGroup parent) {
        viewHolder2 holder = new viewHolder2();
            View view = v;
        if (view==null){
            LayoutInflater inflater=(LayoutInflater)c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view=inflater.inflate(layout,null);


            holder.txt1=(TextView)view.findViewById(R.id.txt12);
            holder.txt2=(TextView)view.findViewById(R.id.txt22);
            holder.txt3=(TextView)view.findViewById(R.id.txt32);
            holder.txt4=(TextView)view.findViewById(R.id.txt42);
            holder.txt5=(TextView)view.findViewById(R.id.txt52);
            holder.txt6=(TextView)view.findViewById(R.id.txt62);
            view.setTag(holder);

        }else{
            holder=(viewHolder2)view.getTag();
        }
        item2 f = foodlist.get(position);
        holder.txt1.setText(String.valueOf(f.getPu()).toString());
        holder.txt2.setText(String.valueOf(f.getTk()).toString());
        holder.txt3.setText(String.valueOf(f.getTp()).toString());
        holder.txt4.setText(String.valueOf(f.getPd()).toString());
        holder.txt5.setText(String.valueOf(f.getUp()).toString());
        holder.txt6.setText(String.valueOf(f.getHasil()).toString());




        return view;
    }
    private class viewHolder2{

        TextView txt1, txt2, txt3, txt4, txt5,txt6;
    }
}
