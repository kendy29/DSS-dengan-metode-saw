package com.ptcintadamai.metodesaw;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {
    public DatabaseHelper(Context context) {
        super(context, "Saw", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table Metode(Pu text not null,Tk text not null,Tp text not null,Pd text not null,Up text not null);");
        db.execSQL("create table Metode2(Pu2 real not null,Tk2 real not null,Tp2 real not null,Pd2 real not null,Up2 real not null,hasil real not null);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("drop table if exists Metode");
        db.execSQL("drop table if exists Metode2");
        onCreate(db);
    }
    public boolean insertData(String Pu,String Tk,String Tp, String Pd, String Up){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("Pu",Pu);
        cv.put("Tk",Tk);
        cv.put("Tp",Tp);
        cv.put("Pd",Pd);
        cv.put("Up",Up);
        long i =db.insert("Metode",null,cv);
        if (i==-1)
            return false;
        else
            return true;
    }
    public boolean insertData2(double Pu, double Tk, double Tp, double Pd, double Up, double hasil){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("Pu2",Pu);
        cv.put("Tk2",Tk);
        cv.put("Tp2",Tp);
        cv.put("Pd2",Pd);
        cv.put("Up2",Up);
        cv.put("hasil",hasil);

        long i =db.insert("Metode2",null,cv);
        if (i==-1)
            return false;
        else
            return true;
    }
    public Cursor getData(String sql){
        SQLiteDatabase database=getWritableDatabase();

        return database.rawQuery(sql,null);
    }

    public Cursor getData2(String sql){
        SQLiteDatabase database=getWritableDatabase();

        return database.rawQuery(sql,null);
    }
    public Cursor getMax(String sql){
        SQLiteDatabase database=getWritableDatabase();


        return database.rawQuery(sql,null);
    }
    public void delete(){
        SQLiteDatabase database=getWritableDatabase();
        database.execSQL("drop table Metode");
        database.execSQL("drop table Metode2");
        onCreate(database);
    }
}
