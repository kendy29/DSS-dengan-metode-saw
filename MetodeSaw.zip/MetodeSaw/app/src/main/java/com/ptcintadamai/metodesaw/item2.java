package com.ptcintadamai.metodesaw;

public class item2 {
    private double Pu;
    private double Tk;
    private double Tp;
    private double Pd;
    private double Up;
    private double hasil;

    public item2(double pu, double tk, double tp, double pd, double up, double hasil) {
        Pu = pu;
        Tk = tk;
        Tp = tp;
        Pd = pd;
        Up = up;
        this.hasil = hasil;
    }

    public double getHasil() {
        return hasil;
    }

    public void setHasil(double hasil) {
        this.hasil = hasil;
    }



    public double getPu() {
        return Pu;
    }

    public void setPu(double pu) {
        Pu = pu;
    }

    public double getTk() {
        return Tk;
    }

    public void setTk(double tk) {
        Tk = tk;
    }

    public double getTp() {
        return Tp;
    }

    public void setTp(double tp) {
        Tp = tp;
    }

    public double getPd() {
        return Pd;
    }

    public void setPd(double pd) {
        Pd = pd;
    }

    public double getUp() {
        return Up;
    }

    public void setUp(double up) {
        Up = up;
    }
}
