package com.ptcintadamai.metodesaw;

public class item {
    private String Pu, Tk, Tp, Pd, Up;
    public item(String pu, String tk, String tp, String pd, String up) {
        Pu = pu;
        Tk = tk;
        Tp = tp;
        Pd = pd;
        Up = up;
    }



    public String getPu() {
        return Pu;
    }

    public void setPu(String pu) {
        Pu = pu;
    }

    public String getTk() {
        return Tk;
    }

    public void setTk(String tk) {
        Tk = tk;
    }

    public String getTp() {
        return Tp;
    }

    public void setTp(String tp) {
        Tp = tp;
    }

    public String getPd() {
        return Pd;
    }

    public void setPd(String pd) {
        Pd = pd;
    }

    public String getUp() {
        return Up;
    }

    public void setUp(String up) {
        Up = up;
    }
}
