package com.ptcintadamai.metodesaw;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText PenilaianUmum, TingkatKehadiran, TingkatPendidikan, PengembanganDiri, UnsurPenunjang;
    Button btnInput;
    DatabaseHelper db;
    ListView listView;
    ListView listView2;
    listAdapter adapter=null;
    listAdapter2 adapter2=null;
    ArrayList<item> list;
    ArrayList<item2> list2;
    private String pu, tp,tk,up,pd;
    private String pu0, tp0,tk0,up0,pd0;
     Button mk, _clear;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        _clear=findViewById(R.id.btnClear);
        mk=findViewById(R.id.matrixKeputusan);
        list2 =new ArrayList<>();
        listView2=findViewById(R.id.listView2);
        list=new ArrayList<>();
        adapter=new listAdapter(MainActivity.this,R.layout.table_metode,list);
        adapter2=new listAdapter2(MainActivity.this,R.layout.table_metode2,list2);
        listView=findViewById(R.id.listView);
        PenilaianUmum=findViewById(R.id.PenilaianUmum);
        TingkatKehadiran=findViewById(R.id.TingkatKehadiran);
        TingkatPendidikan=findViewById(R.id.TingkatPendidikan);
        PengembanganDiri=findViewById(R.id.PengembanganDiri);
        UnsurPenunjang=findViewById(R.id.UnsurPenunjang);
        btnInput=findViewById(R.id.btnInput);
        db = new DatabaseHelper(MainActivity.this);
        listView.setAdapter(adapter);
        listView2.setAdapter(adapter2);
        btnInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String Pu=PenilaianUmum.getText().toString();
                String Tk=TingkatKehadiran.getText().toString();
                String Tp = TingkatPendidikan.getText().toString();
                String Pd=PengembanganDiri.getText().toString();
                String Up = UnsurPenunjang.getText().toString();
                boolean k=db.insertData(Pu,Tk,Tp,Pd,Up);
                if (k==true){
                    Toast.makeText(MainActivity.this, "data berhasil di tambahkan", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this, "data gagal di tambahkan", Toast.LENGTH_SHORT).show();
                }
                PenilaianUmum.setText("");
                TingkatKehadiran.setText("");
                TingkatPendidikan.setText("");
                PengembanganDiri.setText("");
                UnsurPenunjang.setText("");
                list.clear();
                list2.clear();

                if (TextUtils.isEmpty(Pu)){
                    PenilaianUmum.setError("Penilaian Umum tidak boleh kosong");
                }
                if (TextUtils.isEmpty(Tk)){
                    TingkatKehadiran.setError("Tingkat Kehadiran tidak boleh kosong");
                }
                if (TextUtils.isEmpty(Tp)){
                    TingkatPendidikan.setError("Tingkat Pendidikan tidak boleh kosong");
                }
                if (TextUtils.isEmpty(Pd)){
                    PengembanganDiri.setError("Pengembangan diri tidak boleh kosong");
                }
                if (TextUtils.isEmpty(Up)){
                    UnsurPenunjang.setError("Unsur Penunjang tidak boleh kosong");
                }
                Cursor c =db.getData("select * from Metode");

                while (c.moveToNext()){
                     pu0=c.getString(0);
                     tk0=c.getString(1);
                     tp0=c.getString(2);
                     pd0=c.getString(3);
                     up0 = c.getString(4);
                    list.add(new item(pu0,tk0,tp0,pd0,up0));

                }

                adapter.notifyDataSetChanged();

            }
        });
        byte[] bytes;

        mk.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {


                list2.clear();
                Cursor c1=db.getData("select * from Metode2");
                Cursor c =db.getData("select * from Metode");

                while (c.moveToNext()) {
                    pu0 = c.getString(0);
                    tk0 = c.getString(1);
                    tp0 = c.getString(2);
                    pd0 = c.getString(3);
                    up0 = c.getString(4);
                    list.add(new item(pu0, tk0, tp0, pd0, up0));


                    list2.clear();
                    Cursor c2 = db.getData2("select max(Pu) from Metode");
                    Cursor c22 = db.getData2("select max(Tk) from Metode");
                    Cursor c23 = db.getData2("select max(Tp) from Metode");
                    Cursor c24 = db.getData2("select max(Pd) from Metode");
                    Cursor c25 = db.getData2("select max(Up) from Metode");

                    c2.moveToNext();
                    c22.moveToNext();
                    c23.moveToNext();
                    c24.moveToNext();
                    c25.moveToNext();
                    double pu3 = Double.parseDouble(pu0) / c2.getInt(0);
                    double tk3 = Double.parseDouble(tk0) / c22.getInt(0);
                    double tp3 = Double.parseDouble(tp0) / c23.getInt(0);
                    double pd3 = Double.parseDouble(pd0) / c24.getInt(0);
                    double up3 = Double.parseDouble(up0) / c25.getInt(0);
                    double hasil2 = (pu3 * 55) + (tk3 * 20) + (tp3 * 10) + (pd3 * 10) + (up3 * 5);
                    boolean i = db.insertData2(pu3, tk3, tp3, pd3, up3, hasil2);
                    if (i == true) {
                        Toast.makeText(MainActivity.this, "berhasil", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity.this, "gagal", Toast.LENGTH_SHORT).show();
                    }
                    adapter2.notifyDataSetChanged();
                }
                    while(c1.moveToNext()){
                    double j1=c1.getDouble(0);
                    double j2=c1.getDouble(1);
                    double j3= c1.getDouble(2);
                    double j4=c1.getDouble(3);
                    double j5=c1.getDouble(4);
                    double hasil1=c1.getDouble(5);
                    list2.add(new item2(j1,j2,j3,j4,j5,hasil1));
                }
                adapter2.notifyDataSetChanged();

            }
        });

        list.clear();

        Cursor c =db.getData("select * from Metode");
        while (c.moveToNext()){
            pu=c.getString(0);
             tk=c.getString(1);
             tp=c.getString(2);
             pd=c.getString(3);
             up = c.getString(4);
            list.add(new item(pu,tk,tp,pd,up));

        }
        adapter.notifyDataSetChanged();


        list2.clear();
        Cursor c1=db.getData("select * from Metode2");
        while(c1.moveToNext()){
            double j1=c1.getDouble(0);
            double j2=c1.getDouble(1);
            double j3= c1.getDouble(2);
            double j4=c1.getDouble(3);
            double j5=c1.getDouble(4);
            double hasil1=c1.getDouble(5);
            list2.add(new item2(j1,j2,j3,j4,j5,hasil1));
        }
        adapter2.notifyDataSetChanged();
        _clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                list2.clear();
                list.clear();


               db.delete();
               adapter2.notifyDataSetChanged();
               adapter.notifyDataSetChanged();
            }
        });

    }

}
